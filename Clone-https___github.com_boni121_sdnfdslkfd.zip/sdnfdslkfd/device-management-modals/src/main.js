document.addEventListener('DOMContentLoaded', function() {
    // Тестовые данные устройств
    const devices = [
        { id: 'a05705f4...', name: 'луцорлорпвыо' },
        { id: '8fdf9c87...', name: 'fdgf' },
        { id: '83c236f9...', name: 'wb2' },
        { id: '23d9a909...', name: 'wd 3 (kratos)' }
    ];

    // DOM элементы
    const openDevicesBtn = document.getElementById('openDevicesModal');
    const devicesModal = document.getElementById('devicesModal');
    const logModal = document.getElementById('logModal');
    const androidAppsModal = document.getElementById('androidAppsModal');
    const qrCodeModal = document.getElementById('qrCodeModal');
    const editDeviceModal = document.getElementById('editDeviceModal');
    const addDeviceModal = document.getElementById('addDeviceModal');
    const devicesList = document.getElementById('devicesList');
    const closeButtons = document.querySelectorAll('.close-btn');
    const closeDevicesBtn = document.getElementById('closeDevicesBtn');
    const addDeviceBtn = document.getElementById('addDeviceBtn');
    const fromDateInput = document.getElementById('fromDate');
    const toDateInput = document.getElementById('toDate');
    const fromDateCalendar = document.getElementById('fromDateCalendar');
    const toDateCalendar = document.getElementById('toDateCalendar');
    const applyDatesBtn = document.getElementById('applyDates');
    const okLogBtn = document.getElementById('okLogBtn');
    const okAndroidBtn = document.getElementById('okAndroidBtn');
    const okQrBtn = document.getElementById('okQrBtn');
    const copyQrKeyBtn = document.getElementById('copyQrKey');
    const closeEditBtn = document.getElementById('closeEditBtn');
    const closeAddBtn = document.getElementById('closeAddBtn');

    // Функции для модальных окон
    function openModal(modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }

    function closeModal(modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    function closeAllModals() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            closeModal(modal);
        });
    }

    // Первоначальное заполнение списка устройств
    function populateDevicesList() {
        devicesList.innerHTML = '';
        devices.forEach(device => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${device.id}</td>
                <td>
                    <span class="device-status-dot">●</span>
                    ${device.name}
                </td>
                <td>
                    <button class="icon-btn message-btn" data-id="${device.id}" data-name="${device.name}">
                        <i class="fa-regular fa-comment"></i>
                    </button>
                </td>
                <td>
                    <button class="icon-btn android-btn" data-id="${device.id}" data-name="${device.name}">
                        <i class="fa-brands fa-android"></i>
                    </button>
                </td>
                <td>
                    <button class="icon-btn edit-btn" data-id="${device.id}" data-name="${device.name}">
                        <i class="fa-solid fa-pen"></i>
                    </button>
                </td>
                <td>
                    <button class="icon-btn delete-btn" data-id="${device.id}" data-name="${device.name}">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </td>
            `;
            devicesList.appendChild(row);
        });

        // Добавляем обработчики событий для кнопок действий
        addDeviceActionListeners();
    }

    // Обработчики для кнопок действий устройств
    function addDeviceActionListeners() {
        // Лог сообщений
        document.querySelectorAll('.message-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const deviceId = this.getAttribute('data-id');
                const deviceName = this.getAttribute('data-name');
                document.getElementById('logModalTitle').textContent = `Лог сообщений "${deviceName}"`;
                closeModal(devicesModal);
                openModal(logModal);
            });
        });

        // Android приложения
        document.querySelectorAll('.android-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                closeModal(devicesModal);
                openModal(androidAppsModal);
            });
        });

        // Редактирование устройства
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const deviceId = this.getAttribute('data-id');
                const deviceName = this.getAttribute('data-name');

                document.querySelector('#editDeviceModal .device-id').textContent = deviceId;
                document.getElementById('deviceNameInput').value = deviceName;

                closeModal(devicesModal);
                openModal(editDeviceModal);
            });
        });

        // Удаление устройства
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const deviceId = this.getAttribute('data-id');
                if (confirm('Вы действительно хотите удалить это устройство?')) {
                    // Удалить устройство из массива
                    const index = devices.findIndex(device => device.id === deviceId);
                    if (index !== -1) {
                        devices.splice(index, 1);
                        populateDevicesList();
                    }
                }
            });
        });

        // QR код для Android
        document.querySelectorAll('.qr-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                closeModal(androidAppsModal);
                openModal(qrCodeModal);
            });
        });

        // Скачивание приложения
        document.querySelectorAll('.download-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                alert('Скачивание началось...');
                // Здесь был бы код для инициирования скачивания файла
            });
        });
    }

    // Создание календаря
    function createCalendar(year, month, container, selectedDate) {
        const date = new Date(year, month, 1);
        const monthName = date.toLocaleString('ru', { month: 'long' });

        // Обновляем заголовок календаря
        container.querySelector('h3').textContent = `${monthName} ${year}`;

        // Получаем количество дней в месяце
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        // Получаем, с какого дня недели начинается месяц
        let firstDayOfMonth = date.getDay();
        firstDayOfMonth = firstDayOfMonth === 0 ? 7 : firstDayOfMonth; // Преобразуем 0 (воскресенье) в 7

        // Создаем сетку дней
        const daysContainer = container.querySelector('.days');
        daysContainer.innerHTML = '';

        // Добавляем пустые ячейки для дней перед началом месяца
        for (let i = 1; i < firstDayOfMonth; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.textContent = '';
            daysContainer.appendChild(emptyDay);
        }

        // Добавляем дни месяца
        const today = new Date();
        const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;

        for (let i = 1; i <= daysInMonth; i++) {
            const dayElement = document.createElement('div');
            dayElement.textContent = i;
            dayElement.setAttribute('data-day', i);

            // Проверяем, является ли день сегодняшним
            if (isCurrentMonth && i === today.getDate()) {
                dayElement.classList.add('current');
            }

            // Проверяем, является ли день выбранным
            if (selectedDate && selectedDate.getFullYear() === year &&
                selectedDate.getMonth() === month && selectedDate.getDate() === i) {
                dayElement.classList.add('selected');
            }

            // Добавляем обработчик клика
            dayElement.addEventListener('click', function() {
                const day = parseInt(this.getAttribute('data-day'));
                const selected = new Date(year, month, day);

                // Удаляем класс 'selected' у всех дней
                container.querySelectorAll('.days div').forEach(el => {
                    el.classList.remove('selected');
                });

                // Добавляем класс 'selected' к выбранному дню
                this.classList.add('selected');

                // Обновляем значение в поле ввода
                const dateInput = container === fromDateCalendar ? fromDateInput : toDateInput;
                dateInput.value = formatDate(selected);

                // Скрываем календарь при выборе даты
                container.style.display = 'none';
            });

            daysContainer.appendChild(dayElement);
        }
    }

    // Форматирование даты
    function formatDate(date) {
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear();
        return `${day}.${month}.${year}`;
    }

    // Обработчики событий

    // Открытие модального окна устройств
    openDevicesBtn.addEventListener('click', function() {
        populateDevicesList();
        openModal(devicesModal);
    });

    // Закрытие модальных окон
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal');
            closeModal(modal);
        });
    });

    // Закрытие модального окна устройств по кнопке "Закрыть"
    closeDevicesBtn.addEventListener('click', function() {
        closeModal(devicesModal);
    });

    // Открытие модального окна добавления устройства
    addDeviceBtn.addEventListener('click', function() {
        closeModal(devicesModal);
        openModal(addDeviceModal);
    });

    // Поля выбора даты
    fromDateInput.addEventListener('click', function() {
        // Показываем календарь для начальной даты
        fromDateCalendar.style.display = 'block';
        toDateCalendar.style.display = 'none';

        // Создаем календарь на текущий месяц
        const today = new Date();
        createCalendar(today.getFullYear(), today.getMonth(), fromDateCalendar, null);
    });

    toDateInput.addEventListener('click', function() {
        // Показываем календарь для конечной даты
        toDateCalendar.style.display = 'block';
        fromDateCalendar.style.display = 'none';

        // Создаем календарь на текущий месяц
        const today = new Date();
        createCalendar(today.getFullYear(), today.getMonth(), toDateCalendar, null);
    });

    // Применение выбранных дат
    applyDatesBtn.addEventListener('click', function() {
        alert(`Применены даты: от ${fromDateInput.value} до ${toDateInput.value}`);
        // Здесь был бы код для фильтрации логов по датам
    });

    // Кнопки "Ок" для закрытия модальных окон
    okLogBtn.addEventListener('click', function() {
        closeModal(logModal);
        openModal(devicesModal);
    });

    okAndroidBtn.addEventListener('click', function() {
        closeModal(androidAppsModal);
        openModal(devicesModal);
    });

    okQrBtn.addEventListener('click', function() {
        closeModal(qrCodeModal);
        openModal(androidAppsModal);
    });

    // Копирование ключа QR-кода
    copyQrKeyBtn.addEventListener('click', function() {
        const qrKeyInput = document.getElementById('qrKeyInput');
        qrKeyInput.select();
        document.execCommand('copy');
        alert('Ключ скопирован!');
    });

    // Кнопки закрытия модальных окон редактирования и добавления
    closeEditBtn.addEventListener('click', function() {
        closeModal(editDeviceModal);
        openModal(devicesModal);
    });

    closeAddBtn.addEventListener('click', function() {
        closeModal(addDeviceModal);
        openModal(devicesModal);
    });

    // Обработка сохранения изменений при редактировании устройства
    document.querySelector('#editDeviceModal .save-btn').addEventListener('click', function() {
        const deviceId = document.querySelector('#editDeviceModal .device-id').textContent;
        const newName = document.getElementById('deviceNameInput').value;

        // Обновляем имя устройства в массиве
        const device = devices.find(d => d.id === deviceId);
        if (device) {
            device.name = newName;
            populateDevicesList();
        }

        closeModal(editDeviceModal);
        openModal(devicesModal);
    });

    // Обработка отмены изменений при редактировании устройства
    document.querySelector('#editDeviceModal .cancel-btn').addEventListener('click', function() {
        closeModal(editDeviceModal);
        openModal(devicesModal);
    });

    // Обработка сохранения при добавлении нового устройства
    document.querySelector('#addDeviceModal .save-btn').addEventListener('click', function() {
        const newName = document.getElementById('newDeviceNameInput').value;

        if (newName.trim() !== '') {
            // Генерируем случайный ID
            const newId = Math.random().toString(36).substring(2, 10) + '...';

            // Добавляем новое устройство в массив
            devices.push({ id: newId, name: newName });

            // Очищаем поле ввода
            document.getElementById('newDeviceNameInput').value = '';

            // Обновляем список устройств
            populateDevicesList();
        }

        closeModal(addDeviceModal);
        openModal(devicesModal);
    });

    // Обработка отмены при добавлении нового устройства
    document.querySelector('#addDeviceModal .cancel-btn').addEventListener('click', function() {
        // Очищаем поле ввода
        document.getElementById('newDeviceNameInput').value = '';

        closeModal(addDeviceModal);
        openModal(devicesModal);
    });

    // Закрытие календаря при клике вне его
    document.addEventListener('click', function(event) {
        if (!fromDateCalendar.contains(event.target) && event.target !== fromDateInput) {
            fromDateCalendar.style.display = 'none';
        }

        if (!toDateCalendar.contains(event.target) && event.target !== toDateInput) {
            toDateCalendar.style.display = 'none';
        }
    });

    // Временная заглушка для получения QR-кода
    function generateQRCode() {
        // В реальном приложении здесь был бы запрос к API для генерации QR-кода
        return "./qr-code.png";
    }
});
