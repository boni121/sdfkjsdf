export default {
  base: './',
  root: 'src'
}
